# ICAD QMRA Risk Calculator (MYRIAD Post‑hoc)

This is a single‑file web app (`index.html`). Host it on GitHub Pages to get a sharable link.

## Quick start
1) Create a **Public** repo on GitHub (e.g., `ICAD-QMRA-Calculator`).  
2) Upload **`index.html`** to the repo **root**.  
3) Repo → **Settings → Pages** → **Source: Deploy from a branch** → Branch: `main` → Folder: `/ (root)` → **Save**.  
4) Wait ~1–2 minutes. Your site will be live at:  
   ```
   https://<your-username>.github.io/<your-repo-name>/
   ```

## Troubleshooting 404
- Ensure the repo is **Public** (Settings → General → Danger zone).  
- The file must be named **`index.html`** in the **root** of the selected branch.  
- After enabling Pages, check **Actions** tab for `pages-build-deployment` (should be green).  
- Hard refresh the URL (Shift + Reload). It can take a minute to propagate.  
- URLs are **case‑sensitive**.  

## Local use
Just double‑click `index.html` to open it in your browser locally.
